


students = {}

while True:
    print("\n Student Grade Management System")
    print("1. Add Student")
    print("2. Update Student Grades")
    print("3. Print all Student Grades")
    print("4. Exit")

    choice = input("Enter your choice (1-4): ")

    if choice == '1':
        name = input("Enter student name: ")
        grade = int(input("Enter student grade: "))

        if name in students:
            print(f"{name} already exists!")
        else:
            students[name] = grade
            print(f"Student {name} added with grade {grade}")

    elif choice == '2':
        name = input("Enter student name to update: ")
        if name in students:
            new_grade = int(input(f"Enter new grade for {name}: "))
            students[name] = new_grade
            print(f"Student {name}'s grade updated to {new_grade}")
        else:
            print(f"Student {name} not found!")

    elif choice == "3":
        if students:
            print("\nStudent Grades:")
            for name, grade in students.items():
                print(f"{name}: {grade}")
        else:
            print("No students found.")

    elif choice == "4":
        print("Exiting program...")
        break

    else:
        print("Invalid choice! Please enter a number between 1 and 4.")
