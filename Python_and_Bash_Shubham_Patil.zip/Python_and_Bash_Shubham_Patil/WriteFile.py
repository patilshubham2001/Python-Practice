
f = open("file.txt", "w")
f.write("Hi i am shubham patil")
print("File created and written successfully.")
f.close()
